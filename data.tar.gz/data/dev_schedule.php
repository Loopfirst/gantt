<?php

$dev_schedule = array();

$dev_schedule[] = array(
  'label' => 'Idea/Concept',
  'start' => '2013-04-19',
  'end'   => '2014-05-01',
  'info'  => '',
  'color' => 'red',
  'done'  => 'none'
);

$dev_schedule[] = array(
  'label' => 'Build Prototype',
  'start' => '2014-01-01',
  'end'   => '2014-07-15',
  'info'  => '',
  'color' => 'green',
  'done'  => 'none'
);

$dev_schedule[] = array(
  'label' => 'Gather Data',
  'start' => '2014-07-15',
  'end'   => '2014-08-31',
  'info'  => '',
  'color' => 'green',
  'done'  => 'none'
);

$dev_schedule[] = array(
  'label' => 'Marketing',
  'start' => '2014-08-01',
  'info'  => '',
  'color' => 'green',
  'done'  => 'none'
);

$dev_schedule[] = array(
  'label' => 'Invite only Beta',
  'start' => '2014-08-15',
  'info'  => '',
  'color' => 'green',
  'done'  => 'none'
);

?>
