<?php

$back = array();

$back[] = array(
	'label' => 'DBS (Saving Fields)',
	'start' => '2014-04-03',
	'end'   => '2014-04-08',
	'color' => 'red',
	'info'  => 'timeline',
	'done'  => '30',
);

$back[] = array(
	'label' => 'DBS (Indexing/Structuring)',
	'start' => '2014-03-31',
	'color' => 'green',
	'end'   => '2014-04-30',
);

$back[] = array(
	'label' => 'DBS (Querying)',
	'start' => '2014-03-31',
	'end'   => '2014-04-30',
	'color' => 'blue',
);

$back[] = array(
	'label' => 'DBS (Implementing)',
	'start' => '2014-03-31',
	'end'   => '2014-04-30',
	'color' => 'yellow'
);





/* Completed
------------------------- */

$back[] = array(
	'label' => 'DBMS Saving: (user, thread, qa, review, entity, answer,
				image, org, product, service, list)',
	'start' => '2014-03-31',
	'end'   => '2014-04-03',
	'color' => 'completed',
);

?>
