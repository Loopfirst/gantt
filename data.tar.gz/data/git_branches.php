<?php

$git_branches = array();

$git_branches[] = array(
  'label' => 'yc-demo',
  'start' => '2014-03-20',
  'end'   => '2014-04-16',
  'info'  => 'merge into master',
  'color' => 'green',
  'done'  => 'none'
);

?>
