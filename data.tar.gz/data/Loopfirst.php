<?php

$loopfirst = array();

$loopfirst[] = array(
  'label' => 'Idea/Concept',
  'start' => '2014-03-20',
  'end'   => '2014-04-16',
  'info'  => '',
  'color' => 'green',
  'done'  => 'none'
);

$loopfirst[] = array(
  'label' => 'Build Prototype',
  'start' => '2014-03-20',
  'end'   => '2014-04-16',
  'info'  => '',
  'color' => 'green',
  'done'  => 'none'
);

$loopfirst[] = array(
  'label' => 'Marketing',
  'start' => '2014-03-20',
  'end'   => '2014-04-16',
  'info'  => '',
  'color' => 'green',
  'done'  => 'none'
);

$loopfirst[] = array(
  'label' => 'Invite only Beta',
  'start' => '2014-03-20',
  'end'   => '2014-04-16',
  'info'  => '',
  'color' => 'green',
  'done'  => 'none'
);

$loopfirst[] = array(
  'label' => 'Gather Data',
  'start' => '2014-03-20',
  'end'   => '2014-04-16',
  'info'  => '',
  'color' => 'green',
  'done'  => 'none'
);

?>
